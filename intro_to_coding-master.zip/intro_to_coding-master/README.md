# ![GA-Cog](https://avatars2.githubusercontent.com/u/42252722?s=200&v=4) Welcome to Intro to Coding HTML and CSS

This is what we'll be building today!

![landing Page Prototype](imgs/prototype.png)
